# Leon Czarlnski
# n01541167

## Question 10

### Convert data.xml into json format and make a function that would provide the total count of all the trips made by all the passengers
- [X] Check the JSON file [Here](passengers.json)
- [X] Check the validator [Here](JSON_Validator.png)
- [X] Check the output [Here](output1854.png)