const passenger = [{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},

{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
},
{
    "nameP": "John Doe",
    "trips": 250,
    "country":"Taiwan",
    "established" : "1989",
    "head_quarters" : "376, Hsin-Nan Rd., Sec. 1, Luzhu, Taoyuan City, Taiwan",
    "id":"5",
    "logo":"https://upload.wikimedia.org/wikipedia/en/thumb/e/ed/EVA_Air_logo.svg/250px-EVA_Air_logo.svg.png</logo>",
    "name":"Eva Air",
    "slogan":"Sharing the World, Flying Together",
    "website":"www.evaair.com"
}]
// Aycan Lizor_N01534088
console.log(`Source:`);
console.log(passenger);

function total (){
    let travels=0;
    for(i=0 ; i < passenger.length ; i++){
    
        travels = travels + passenger[i]["trips"];
      }

      console.log("Total trips :" +travels)
}

total();

  
 