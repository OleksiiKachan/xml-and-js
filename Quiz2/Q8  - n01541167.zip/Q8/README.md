# Leon Czarlnski
# n01541167

## Question 08

### Create functions to parse data from data.json. You will need to use .filter(), .map(), and .reduce()
- [X] Function to get array of active accounts only
- [X] Function to get the highest balance. Function should return balance string value
- [X] Function to get array of friends of all accounts. Function should return array names
- [X] Function to get string of account holders names. Function should return a single string with comma separated names

### Answer: to access the answer [ClickHere](data.js)
### Answer: to check the output [ClickHere](output.png)

