
## Team Contribution to the project


## Anwar COntribution to the Project

Step 5: I have created the XSD file for the XML file that has been created by Aditi and it has been validated againist the XML file and xsd file is valid. The Screenhsot is attached.

![XSD vs XML Validation Screenshot](./XSD_Validation.png)

Step 6: 
Next I worked on the XSLT and represented the whole data in the tabluar format. Here in this data i have created with four columns with Names Company id, Address, Employees, Drugs

Next i have used the xsl for each and inserted the data where it will insert the ids first and then goes to the next column and inserts the adress and in this Adress i have created inner table with four rows (street, city, region, country)

next it goes to the employees coloumn and inserts the data for the three employees as each set is having three employees with fields (id, firstname, lastname, emptype)
![XSL file linked with xml and taken screenshot of output](./Ouptut_XSLT.png)






