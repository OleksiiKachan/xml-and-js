## Aditi or Jay COntribution to the project

Step 1: Analyzing the Json file

 The given Json looks like that there are certain companies which shows the details such as the Id of the company along with the Address  (Street, city, region , country) and the employess along with thier id's, firstname, lastname, emptype and the drugs used by these different comapnies which shows the information about the Manufacturer, brand, name, code, Diagnosis code, diagnosis description, Quantity.

 Overall there are 15 different companies for which the data is shown 

Step2: 
I have used the .Json file and  started working on creating the XML file. 
 ![Xml file ](./clinic.xml)

Step 3: 
I have created the XML and then I started working on DTD for the created XML.

Step 4 : I have Created the DTD for the Above XML file and validated using the tool and there were no errors found 
![DTD Validation Screenshot of DTD](./DTD_Validation.png)