# Activity

- Create Spotify dev account​
- Create new app​
- Using your client id and client secret create html page to display genres and playlists by genres (don't copy my page design)
