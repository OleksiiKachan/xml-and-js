# Activity

- Rewrite sync.js using Promises​
- Attach screenshot of the output in your terminal
