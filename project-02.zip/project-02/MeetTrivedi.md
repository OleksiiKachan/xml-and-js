# Project -1

# Gropu -8
## Topic- Clinic

- I have created scrip file in javascript 
- I have implimented function to fetch api data and return it as html elements.