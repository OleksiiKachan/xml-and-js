# Project2
Aycan Lizor N01534088

- All groupmades came together and we did the Project together. I cannot seperate our job. 
- First step we try to understand "https://www.carboninterface.com"
- We tried to understan the documnetaion for this API
- We fetch the datas and figured out how to get json file
- We eliminate the redundant information in the array
- We added simple css to the project
