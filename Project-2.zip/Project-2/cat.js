var token = 'live_1EeIlchSbiPqtqiQKzkGTusxyD9IakCtsEBlF35SFC2jymIfr1ARqibsKGvaI4nD';
let _data = [];

const getlogos = async (token, term) => {
  const result = await fetch(
    `https://api.thecatapi.com/v1/images/search?query=${term}`,
    {
      method: "GET",
      headers: { Authorization: "Bearer " + token },
    }
   
  );
   _data = await result.json();
  return _data.images ;
};





const renderHTML =  (term) => {
  const htmlBody = document.getElementById("genres");
  let source = _data;
  if (term) { 
      htmlBody.innerHTML = "";
        source.map(({id, url})=>{
        let html = `
        
        <img class="icon" src="${id}"/> 
        
        
        <div class="domain">Domain: ${url}</div>
   
    
        `; 
        htmlBody.insertAdjacentHTML("beforeend", html);
      })
  }
  else
  {
    htmlBody.innerHTML = "";
        let html = `
        <div class="card">
        </div>
        `;
        htmlBody.insertAdjacentHTML("beforeend", html);
  }
};
 console.log(`data rendered`);
const onSubmit = (event) => {
  event.preventDefault();
  const term = event.target.term.value;
  getlogos(token , term);
  renderHTML(term);
};

const onReset = () => {
  renderHTML();
};
  