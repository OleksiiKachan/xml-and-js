# Activity 2

1. Create XSD for `week-3/products.xml` and save file as `week-3/assignments/activity-2.xsd`
2. Validate it using [https://www.freeformatter.com/xml-validator-xsd.html](https://www.freeformatter.com/xml-validator-xsd.html) and take a screenshot of validation results
