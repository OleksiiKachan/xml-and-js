Contributions: DTD-XMl and Xsl files
For DTD, we start with the root element , followed by the main and child elements respectively. We specify the respective content-type for each element. Next we also specify the cardinality for each occuring tags/elements. We complete the DTD with specifying each element its children , its content type and theirs cardinality. We have also checked for its validity in the validatior.
For the xsl file, we will be mentioning how we want the browser to render our xml file. In this case, we want a table.We will also include the xsl path info in the xml file.We then mention all the major tags as our column names, since we want a table of our XML data.Since animals have multiple records for each Id we also form a table inside the record. Similarly, there are multiple employees for each ID, so form a table inside that record as well.


The XML and CSS files we worked on by both the team members together.