Cat API

Hinal Amin-N01530824
Dhruv Desai-N01511490
Prachi KaPatel-N01530881
