const loadData = () => {
  /**
   * load data from https://6253799f90266e3d0e0373e6.mockapi.io/ok/user
   */
};

loadData().then((data) => {
  /**
   * render data in html table
   */
});
