# Quiz 4

## Part 1

- open folder and run `npm install`
- run `npm run main` to see empty outputs
- implement functions in questions/ folder to make tests work (you can run `npm run q1`/`npm run q2`/... to run tests only for a single question)
- update `loadData` function in `main.js`

## Part 2

- create html page and update js file to load and render data:
  - html/users.html - should have a table with all the uses loaded from the api excluding address and vehicle fields
