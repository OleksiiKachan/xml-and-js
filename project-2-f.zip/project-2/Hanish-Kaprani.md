Contribution to project:
API call, breeds and genders.
Html and basic css