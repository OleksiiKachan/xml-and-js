Contribution to the project:
API CALL, types of animals.
Main styling of the pages and list.