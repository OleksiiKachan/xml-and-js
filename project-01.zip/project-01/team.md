# Project -1

# Gropu -8
## Topic- Clinic

## Team members:

- Abhishek Umeshbhai Pandya (n01511627)
- Meet Hiteshkumar Trivdi (N01520331)
- Raghavender Chakilam (n01533573)