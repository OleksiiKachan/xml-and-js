# Project -1

# Gropu -8
## Topic- Clinic

- I have created Html page using javascript api call 
- I have implimented function to read, parse and append html element to web page of given xml page