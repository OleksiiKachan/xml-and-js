I made 
1. XML
-Firstly, I created XML from JSON File.

2. DTD
-Then I proceeded to make DTD.
-Now, while making DTD from the XML file we have multiple tag with name Branch. Plus, it's expanding further to id, name street, etc. So (branch+) has been used.
-Same goes for the clients Part
-Now for cards: - A client can have 0 to multiple cards for that I used "*"

3. Bank.html
-I created Bank.html and added limited styling for the same.