# Project 2

- Created html, css, js for showing details about crypto currencies: name, icon, symbol, max_supply:
    - got api access key and fetched data about crypto currencies.
    - created html and css to display information in appropriate format
    - created filter to filter cards by their symbols
    - use the same information/data each time filtering data using ajax pattern/structure.
