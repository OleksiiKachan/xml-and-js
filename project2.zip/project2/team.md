# Project 2 list of team members

- Alla-Anastasiia Gnatkiv (n01525207)
- Santosh Dhakal (n01530850)
