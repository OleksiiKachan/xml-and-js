# Currency Converter

- Created html and css to take user input for currency and conversion amount
- Fetched currency rates data from coinlayer api
- Populated select option based on fetched data
- Created logic to convert currency

