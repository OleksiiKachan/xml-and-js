# Activity 1

- Take your module-5 activity​
- Write _promisified_ version of XHR​
- Use your new function to load data instead of using XHR directly​
