# Activity 2

- Take your module-5 activity​
- Replace XHR with fetch()​
